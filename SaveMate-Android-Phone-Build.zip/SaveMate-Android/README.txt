SAVEMATE ANDROID PROJECT
========================

This is an Android Studio project that wraps your Savings Goal HTML app
in an Android WebView. The app label is SaveMate and amounts display in PHP (₱).

BUILD YOUR APK (Windows)
------------------------
1. Install Android Studio from https://developer.android.com/studio
2. Extract this ZIP to a folder on your PC.
3. Open Android Studio.
4. Choose Open, then select the extracted SaveMate-Android folder.
5. Allow Android Studio to sync Gradle and install the Android SDK if prompted.
6. When sync finishes, choose Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Android Studio will show a notification with a link to the APK.
   The usual output location is:
   app/build/outputs/apk/debug/app-debug.apk

INSTALL ON YOUR PHONE
---------------------
Transfer app-debug.apk to your Android phone, open it, and allow installation
from that source if Android asks. Only install APKs you built or trust.

PROJECT DETAILS
---------------
App name: SaveMate
Package: com.savemate.app
Currency: PHP / Philippine Peso
Minimum Android version: Android 6.0 (API 23)

NOTES
-----
- Your savings goal and deposit history are stored locally in the app's
  WebView storage on that device.
- No account or cloud sync is included.
- This environment does not have the Android SDK or Gradle installed, so
  this ZIP contains the ready-to-open Android Studio source project, not
  a compiled APK.
